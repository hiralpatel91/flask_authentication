# from flask_sqlalchemy import SQLAlchemy

# db = SQLAlchemy()


# class User(db.Model):
#     id=db.Column(db.Integer, primary_key=True)
#     username=db.Column(db.String(255), nullable=False)
#     email=db.Column(db.String(255), nullable=False)
#     password=db.Column(db.String(255), nullable=False)
#     status=db.Column(db.Integer,default=0, nullable=False)
    
#     def __repr__(self):
#         return f'User("{self.id}","{self.email}","{self.username}","{self.status}")'

# # admin class
# class Admin(db.Model):
#     id=db.Column(db.Integer, primary_key=True)
#     username=db.Column(db.String(255), nullable=False)
#     password=db.Column(db.String(255), nullable=False)
    
#     def __repr__(self):
#         return f'User("{self.id}","{self.username}")'
    
