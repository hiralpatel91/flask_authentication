from flask import Flask,render_template,request,redirect,flash,session
from flask_session import Session
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
import datetime

my_app = Flask(__name__)
my_app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///music.sqlite"
my_app.config["SECRET_KEY"] = "3889257f36e8095a8b229b26"
my_app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
my_app.config["SESSION_PERMANENT"]=False
my_app.config["SESSION_TYPE"]='filesystem'
db = SQLAlchemy(my_app)
bcrypt = Bcrypt(my_app)
Session(my_app)
my_app.app_context().push()


#user class
class User(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    username=db.Column(db.String(255), nullable=False)
    email=db.Column(db.String(255), nullable=False)
    password=db.Column(db.String(255), nullable=False)
    status=db.Column(db.Integer,default=0, nullable=False)
    
    def __repr__(self):
        return f'User("{self.id}","{self.email}","{self.username}","{self.status}")'

# admin class
class Admin(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    username=db.Column(db.String(255), nullable=False)
    password=db.Column(db.String(255), nullable=False)
    
    def __repr__(self):
        return f'User("{self.id}","{self.username}")'
    
    
# creator class
class Creator(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    username=db.Column(db.String(255), nullable=False)
    email=db.Column(db.String(255), nullable=False)
    password=db.Column(db.String(255), nullable=False)
    status=db.Column(db.Integer,default=0, nullable=False)
    
    def __repr__(self):
        return f'Creator("{self.id}","{self.email}","{self.username}","{self.status}")'
    
    
class Album(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    artist = db.Column(db.String(100), nullable=False)
    release_date = db.Column(db.Date)
    creator_id = db.Column(db.Integer, db.ForeignKey('creator.id'), nullable=False)
    songs = db.relationship('Song', backref='album', lazy=True)
    date_added = db.Column(db.DateTime, default=db.func.current_timestamp())

class Song(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    lyrics = db.Column(db.Text)
    genre = db.Column(db.String(50))
    duration = db.Column(db.Float)
    date_created = db.Column(db.DateTime, default=db.func.current_timestamp())
    albums = db.relationship('Album', backref='song', lazy=True)

    
db.create_all()

# admin=Admin(username='hilal123',password=bcrypt.generate_password_hash('hilal123',10))
# db.session.add(admin)
# db.session.commit()
    
# Main Index File
@my_app.route("/")
def Index():
    return render_template("index.html",title="")



# admin Login
@my_app.route("/admin/",methods=['GET','POST'])
def AdminIndex():
    if request.method=="POST":
        # get the name of the field
        username=request.form.get('username')
        password=request.form.get('password')
        
        if username=="" and password=="":
            flash('Please fill all the field','danger')
            return redirect('/admin/')
        else:
            admins=Admin().query.filter_by(username=username).first()
            if admins and bcrypt.check_password_hash(admins.password,password):
                session['admin_id'] = admins.id
                session['admin_name'] = admins.username
                flash('Login Successfully','success')
                return redirect('/admin/dashboard')
            
            else:
                flash('Invaild Email and password','danger')
                return redirect('/admin/')
            
    return render_template("admin/index.html",title="Admin Login")

# admin Dahboard
@my_app.route('/admin/dashboard')
def adminDashboard():
    if not session.get('admin_id'):
        return redirect('/admin/')
    totalUser = User.query.count()
    totalApprove = User.query.filter_by(status=1).count()
    NotTotalApprove = User.query.filter_by(status=0).count()
    totalcreator = Creator.query.count()
    
    return render_template('admin/dashboard.html',title='Admin Dashboard',totalUser=totalUser,
                           totalApprove=totalApprove,NotTotalApprove=NotTotalApprove,totalcreator=totalcreator)



# _________________________________________admin aprrove user_____________________________________________
@my_app.route('/admin/get-all-user',methods=['GET','POST'])
def adminGetAllUser():
    if not session.get('admin_id'):
        return redirect('/admin/')
    if request.method == 'POST':
        search=request.form.get('search')
        users=User.query.filter(User.username.like('%'+search+'%')).all()
        return render_template('admin/all-user.html',title='Approve User',users=users)
    else:
        users=User.query.all()
        return render_template('admin/all-user.html',title='Approve User',users=users)

@my_app.route('/admin/approve-user/<int:id>')
def AdminApprove(id):
    if not session.get('admin_id'):
        return redirect('/admin/')
    User().query.filter_by(id=id).update(dict(status=1))
    db.session.commit()
    flash('Approve Successfully','success')
    return redirect('/admin/get-all-user')


# _________________________________________admin aprrove creator_____________________________________________

@my_app.route('/admin/get-all-creator',methods=['GET','POST'])
def adminGetAllCreator():
    if not session.get('admin_id'):
        return redirect('/admin/')
    if request.method == 'POST':
        search=request.form.get('search')
        creators=Creator.query.filter(Creator.username.like('%'+search+'%')).all()
        return render_template('admin/all-creator.html',title='Approve creator',creators=creators)
    else:
        creators=Creator.query.all()
        return render_template('admin/all-creator.html',title='Approve User',creators=creators)
    
    
@my_app.route('/admin/approve-creator/<int:id>')
def AdminApproveCreator(id):
    if not session.get('admin_id'):
        return redirect('/admin/')
    Creator().query.filter_by(id=id).update(dict(status=1))
    db.session.commit()
    flash('Approve Successfully','success')
    return redirect('/admin/get-all-creator')

    

# change admin password
@my_app.route('/admin/admin-change-password',methods=['GET','POST'])
def adminChangePassword():
    admin=Admin.query.get(1)
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username=="" or password=="":
            flash("please fill the field",'danger')
            return redirect('/admin/admin-change-password')
        
        else:
            Admin().query.filter_by(username=username).update(dict(password=bcrypt.generate_password_hash(password,10)))
            db.session.commit()
            flash("Admin Password Chnaged Successfully",'success')
            return redirect('/admin/admin-change-password')
    else:
        return render_template('/admin/admin-change-password.html',title='Admin Change Password',admin=admin)




# admin logout
@my_app.route('/admin/logout')
def  adminLogout():
    if not session.get('admin_id'):
        return redirect('/admin/')
    if session.get('admin_id'):
        session['admin_id']=None
        session['admin_name']=None
        return redirect('/')    


# ________________________________________User Area____________________________________________________
# User Login
@my_app.route("/user/",methods=["GET","POST"])
def UserIndex():
   if session.get('user_id'):
        return redirect('/user/dashboard')
   if request.method=="POST":
        # get the name of the field
        email=request.form.get('email')
        password=request.form.get('password')
        # check user exist in this email or not
        users=User().query.filter_by(email=email).first()
        if users and bcrypt.check_password_hash(users.password,password):
            # check the admin approve your account are not
            is_approve=User.query.filter_by(id=users.id).first()
            # first return the is_approve:
            if is_approve.status == 0:
                flash('Your Account is not approved by Admin','danger')
                return redirect('/user/')
            else:
                session['user_id']=users.id
                session['username']=users.username
                flash('Login Successfully','success')
                return redirect('/user/dashboard')
        else:
            flash('Invalid Email and Password','danger')
            return redirect('/user/')
   else:
        return render_template('user/index.html',title="User Login")
# User Register
@my_app.route("/user/signup",methods=['GET','POST'])
def UserSignUp():
    if session.get('user_id'):
        return redirect('/user/dashboard')
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        if email=="" or password=="" or username=="":
            flash('Please fill all the field','danger')
            return redirect('/user/signup')
        
        else:
            is_email=User().query.filter_by(email=email).first()
            if is_email:
                flash('Email already Exist','danger')
                return redirect('/user/signup')
            else:
                hash_password = bcrypt.generate_password_hash(password,10)
                user = User(email=email,password=hash_password,username=username)
                db.session.add(user)
                db.session.commit()
                flash('Account Create Successfully Admin Will approve your account in 10 to 30 mint', 'success')
                return redirect('/user/')
            
    return render_template("user/signup.html",title="User Register")

# user dashboard
@my_app.route('/user/dashboard')
def userDashboard():
    if not session.get('user_id'):
        return redirect('/user/')
    if session.get('user_id'):
        id=session.get('user_id')
    users=User().query.filter_by(id=id).first()
    return render_template('user/dashboard.html',title="User Dashboard",users=users)


# userlogout
@my_app.route("/user/logout")
def userLogout():
    if not session.get('user_id'):
        return redirect('/user/')
    if session.get('user_id'):
        session['user_id']=None
        session['username']=None
        return redirect('/user/')

# user change password
@my_app.route('/user/change-password',methods=['POST','GET'])
def UserChangePassword():
    if not session.get('user_id'):
        return redirect('/user/')
    
    if request.method=='POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        if email=="" or password=="":
            flash('Please fill the field','danger')
            return redirect('/user/change-password')
        else:
            users=User().query.filter_by(email=email).first()
            
            if users:
                hash_password = bcrypt.generate_password_hash(password,10)
                User().query.filter_by(email=email).update(dict(password=hash_password))
                db.session.commit()
                flash('Password Changed Successfully','success')
                return redirect('/user/change-password')
            else:
                flash('Invalid Email','danger')
                return redirect('/user/change-password')
            
    return render_template('user/change-password.html',title="Change-Password")


@my_app.route('/user/update-profile',methods=['GET','POST'])
def UserUpdateProfile():
    if not session.get('user_id'):
        return redirect('/user/')
    if session.get('user_id'):
        id = session.get('user_id')
    users = User.query.get(id)
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        
        if email=="" or username=="":
            flash('Please fill the field','danger')
            return redirect('/user/update-profile')
        else:
            User().query.filter_by(id=id).update(dict(username=username,email=email))
            db.session.commit()
            flash('profile update successfully','success')
            return redirect('/user/update-profile')
    return render_template('user/update-profile.html',title='Update-Profile',users=users)



    
# ________________________________________Creator Area____________________________________________________

# creator register
@my_app.route("/creator/signup",methods=['GET','POST'])
def CreatorSignUp():
    if session.get('creator_id'):
        return redirect('/creator/dashboard')
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        if email=="" or password=="" or username=="":
            flash('Please fill all the field','danger')
            return redirect('/creator/signup')
        
        else:
            is_email=Creator().query.filter_by(email=email).first()
            if is_email:
                flash('Email already Exist','danger')
                return redirect('/creator/signup')
            else:
                hash_password = bcrypt.generate_password_hash(password,10)
                creator = Creator(email=email,password=hash_password,username=username)
                db.session.add(creator)
                db.session.commit()
                flash('Account Create Successfully Admin Will approve your account in 10 to 30 mint', 'success')
                return redirect('/creator/')
            
    return render_template("creator/signup.html",title="Creator Register")



# creator login
@my_app.route("/creator/",methods=["GET","POST"])
def CreatorIndex():
   if session.get('creator_id'):
        return redirect('/creator/dashboard')
   if request.method=="POST":
        # get the name of the field
        email=request.form.get('email')
        password=request.form.get('password')
        # check user exist in this email or not
        creators=Creator().query.filter_by(email=email).first()
        if creators and bcrypt.check_password_hash(creators.password,password):
            # check the admin approve your account are not
            is_approve=Creator.query.filter_by(id=creators.id).first()
            # first return the is_approve:
            if is_approve.status == 0:
                flash('Your Account is not approved by Admin','danger')
                return redirect('/creator/')
            else:
                session['creator_id']=creators.id
                session['username']=creators.username
                flash('Login Successfully','success')
                return redirect('/creator/dashboard')
        else:
            flash('Invalid Email and Password','danger')
            return redirect('/creator/')
   else:
        return render_template('creator/index.html',title="Creator Login")

# creator logout
@my_app.route("/creator/logout")
def creatorLogout():
    print(session.get('creator_id'))  # Check the value of creator_id in the session
    if not session.get('creator_id'):
        print("Redirecting to /creator/")
        return redirect('/creator/')
    if session.get('creator_id'):
        print("Logging out...")
        session['creator_id'] = None
        session['username'] = None
        return redirect('/creator/')
    
    
    
# creator change-password
@my_app.route('/creator/change-password',methods=['POST','GET'])
def CreatorChangePassword():
    if not session.get('creator_id'):
        return redirect('/creator/')
    
    if request.method=='POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        if email=="" or password=="":
            flash('Please fill the field','danger')
            return redirect('/creator/change-password')
        else:
            creators=Creator().query.filter_by(email=email).first()
            
            if creators:
                hash_password = bcrypt.generate_password_hash(password,10)
                Creator().query.filter_by(email=email).update(dict(password=hash_password))
                db.session.commit()
                flash('Password Changed Successfully','success')
                return redirect('/creator/change-password')
            else:
                flash('Invalid Email','danger')
                return redirect('/creator/change-password')
            
    return render_template('creator/change-password.html',title="Change-Password")


# creator update-profile
@my_app.route('/creator/update-profile',methods=['GET','POST'])
def CreatorUpdateProfile():
    if not session.get('creator_id'):
        return redirect('/creator/')
    if session.get('creator_id'):
        id = session.get('creator_id')
    creators = Creator.query.get(id)
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        
        if email=="" or username=="":
            flash('Please fill the field','danger')
            return redirect('/creator/update-profile')
        else:
            Creator().query.filter_by(id=id).update(dict(username=username,email=email))
            db.session.commit()
            flash('profile update successfully','success')
            return redirect('/creator/update-profile')
    return render_template('creator/update-profile.html',title='Update-Profile',creators=creators)



# creator dashboard
@my_app.route('/creator/dashboard')
def creatorDashboard():
    if not session.get('creator_id'):
        return redirect('/creator/')
    if session.get('creator_id'):
        id=session.get('creator_id')
    creators=Creator().query.filter_by(id=id).first()
    return render_template('creator/dashboard.html',title="User Dashboard",creators=creators)



if __name__ == "__main__":
    my_app.run(debug=True)
    
    
    
    