from wtforms import StringField,TextAreaField,PasswordField,SubmitField,validators,Form,ValidationError
from flask_wtf.file import FileField,FileRequired,FileAllowed
from flask_wtf import FlaskForm
from .models import Register

class CustomerRegisterForm(FlaskForm):
    name = StringField('Name: ')
    username = StringField('Username: ', [validators.DataRequired()])
    email = StringField('Email: ', [validators.DataRequired()])
    password = PasswordField('Password: ', [validators.DataRequired(), validators.EqualTo('confirm',message='Both Password Must Match!')])
    confirm = PasswordField('Repeat Password: ', [validators.DataRequired()])
    country = StringField('Country: ', [validators.DataRequired()])
    # state = StringField('State: ', [validators.DataRequired()])
    city = StringField('City: ', [validators.DataRequired()])
    contact = StringField('Contact: ', [validators.DataRequired()])
    address = StringField('Address: ', [validators.DataRequired()])
    zipcode = StringField('Zip Code: ', [validators.DataRequired()])
    
    profile = FileField('Profile',validators=[FileAllowed(['jpg','png','jpeg','gif'],'Image only Please')])
    submit = SubmitField('Register')
    
    def validate_username(self, username):
        if Register.query.filter_by(email=username.data).first():
            raise ValidationError("This Username is already in use!")
        
    def validate_username(self, email):
        if Register.query.filter_by(email=email.data).first():
            raise ValidationError("This Email is already in use!")
        
        
class CustomerLoginForm(FlaskForm):
    email = StringField('Email: ', [validators.DataRequired()])
    password = PasswordField('Password: ', [validators.DataRequired()])
    # submit = SubmitField('Login')