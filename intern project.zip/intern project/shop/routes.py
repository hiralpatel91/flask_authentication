from flask import render_template, session, request, redirect, url_for,Blueprint,flash,current_app
import os,secrets
from shop import app, db, photos,bcrypt,check_password_hash
from shop.models import TODO,User
from flask_login import login_required,login_user,logout_user



bp = Blueprint('shop',__name__)


@app.route("/",methods=['POST','GET'])
@login_required
def hello_world():
    if request.method == 'POST':
        title = request.form['title']
        desc = request.form['desc']
        img = photos.save(request.files['img'])
        
        tdata = TODO(title=title,desc=desc,img=img)
        db.session.add(tdata)
        db.session.commit()
    return render_template('home.html')


@app.route('/register',methods=['POST','GET'])
def  register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm = request.form.get('confirm')
        
        if password!=confirm:
            flash("Password and Confirm Password does not match",'danger')
            return redirect('/register')
        hash_password = bcrypt.generate_password_hash(password).decode('utf-8')
        new = User(username=username,email=email,password=hash_password)
        db.session.add(new)
        db.session.commit()
        return redirect('/')
    return render_template('register.html')


@app.route('/login',methods=['GET','POST'])
def login():
    if request.method == 'POST':
            username = request.form.get('username')
            password = request.form.get('password')
            
            user = User.query.filter_by(username=username).first()
            if user and check_password_hash(user.password, password):
                login_user(user)
                flash('Login successful!', 'success')
                return redirect('login')

            flash('Invalid username or password. Please try again.', 'danger')


    return render_template('login.html')


@app.route('/logout')
def logout():
    logout_user()
    return redirect('/')


@app.route('/show')
def show():
    todo = TODO.query.all()
    return render_template('show.html',todo=todo)


@app.route('/update/<int:sno>',methods=['GET','POST'])
def update(sno):
    if request.method == 'POST':
        title = request.form['title']
        desc = request.form['desc']
        
        todo = TODO.query.filter_by(sno=sno).first()
        todo.title = title
        todo.desc = desc
        
        db.session.add(todo)
        db.session.commit()
        return redirect('/show')

        
    todo = TODO.query.filter_by(sno=sno).first()

        
    return render_template('update.html',todo=todo)
    

if __name__ == "__main__":
    app.run(debug=True)
    
    
    
 # >>> import secrets
# >>> secrets.token_hex(6)
# '168796d68ac6'