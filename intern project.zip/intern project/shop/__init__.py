from flask import Flask,render_template,request,flash,redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_login import LoginManager,UserMixin,login_user,logout_user,login_required
from flask_bcrypt import Bcrypt,check_password_hash
from flask_uploads import UploadSet,configure_uploads,IMAGES
import os 
app = Flask(__name__)
basedir = os.path.abspath(os.path.dirname(__file__))

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///project.db"
app.config["SECRET_KEY"] = "168796d68ac6"
app.config['UPLOADED_PHOTOS_DEST'] =  os.path.join(basedir, 'static/uploads')
photos = UploadSet('photos',IMAGES)
configure_uploads(app, photos)


db = SQLAlchemy(app)
app.app_context().push()
bcrypt = Bcrypt(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view='login'
login_manager.needs_refresh_message_category='danger'
login_manager.login_message = u'please login first'

def create_app():
    from shop.routes import bp
    app.register_blueprint(bp)
    return app

